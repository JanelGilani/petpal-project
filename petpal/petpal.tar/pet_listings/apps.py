from django.apps import AppConfig


class PetListingsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pet_listings'
