# Purpose: Initialize views for applications.

# eg:
# from .shopview import CategoryListView
# from .cartview import OrderAddView, OrderRemoveView, OrderDetailView
